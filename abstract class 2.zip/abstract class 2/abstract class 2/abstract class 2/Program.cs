﻿using System;

// Abstract class
abstract class Animal
{
    // Properties
    public string Name { get; set; }
    public string Colour { get; set; }
    public int Age { get; set; }

    // Abstract method
    public abstract void Eat();
}

// Dog class
class Dog : Animal
{
    // Implementation of abstract method
    public override void Eat()
    {
        Console.WriteLine("Dogs eat meat.");
    }
}

// Cat class
class Cat : Animal
{
    // Implementation of abstract method
    public override void Eat()
    {
        Console.WriteLine("Cats eat mice.");
    }
}

class Program
{
    static void Main()
    {
        // Test Dog object
        Console.WriteLine("Enter a dog name: ");
        string dogName = Console.ReadLine();
        Dog myDog = new Dog();
        myDog.Name = dogName;
        myDog.Colour = "Brown";
        myDog.Age = 3;

        Console.WriteLine($"Dog Name: {myDog.Name}");
        Console.WriteLine($"Dog Colour: {myDog.Colour}");
        Console.WriteLine($"Dog Age: {myDog.Age}");
        myDog.Eat();

        // Test Cat object
        Console.WriteLine("\nEnter a cat name: ");
        string catName = Console.ReadLine();
        Cat myCat = new Cat();
        myCat.Name = catName;
        myCat.Colour = "White";
        myCat.Age = 2;

        Console.WriteLine($"Cat Name: {myCat.Name}");
        Console.WriteLine($"Cat Colour: {myCat.Colour}");
        Console.WriteLine($"Cat Age: {myCat.Age}");
        myCat.Eat();
    }
}
